#!/usr/bin/env bash
TakeLock()
{
    echo "in takeLock"
    if mkdir $LockFile; then
        return 2
    else
        sleep 10
        TakeLock
    fi
    echo "exiting takelock"
}

ReleaseLock()
{
    echo "in ReleaseLock"
    if [ -d "$LockFile" ]; then
        rm -rf "$LockFile"
        return 3
    fi
}
cd "$(dirname "${BASH_SOURCE[0]}")"
LockFile="lock"


# The __TestEnv variable may be used to specify a script to source before the test.
if [ -n "$__TestEnv" ]; then
    source $__TestEnv
fi


        
      


usage()
{
    echo "Usage: $0  "
    echo 
    echo "Arguments:"
    echo "-debug=debuggerFullPath"
    echo      "Run testcases under debugger."
    echo "-coreroot=coreRootFullPath"
    echo      "Set CORE_ROOT to the specified value before running the test."
    echo "-?,-h,--help    show this message"
    exit 1
}

# Parse Command Line

for i in "$@"
    do
        case $i in
        -?|-h|--help)
        usage
        ;;
        -debug=*|/debug=*)
        export _DebuggerFullPath="${i#*=}"
        if [ ! -f "$_DebuggerFullPath" ]
        then
            echo "The Debugger FullPath \"${_DebuggerFullPath}\" does not exist"
            usage
        fi
        ;;
-coreroot=*|/coreroot=*)
        export CORE_ROOT="${i#*=}"
        ;;
        *)
        CLRTestExecutionArguments+=("${i}")
    esac
done


      

if [ -z ${CLRTestExpectedExitCode+x} ]; then export CLRTestExpectedExitCode=100; fi
echo BEGIN EXECUTION

# JitDisasm Script
if [ ! -z $RunningJitDisasm ]
then
    echo $CORE_ROOT/corerun "$CORE_ROOT/jit-dasm.dll" --crossgen $CORE_ROOT/crossgen --platform $CORE_ROOT --output ../../../../../../dasm/CoreMangLib/system/runtime/interopservices/marshal/MarshalSizeOf2_PSC MarshalSizeOf2_PSC.exe
    "$CORE_ROOT/corerun" "$CORE_ROOT/jit-dasm.dll" --crossgen $CORE_ROOT/crossgen --platform $CORE_ROOT --output ../../../../../../dasm/CoreMangLib/system/runtime/interopservices/marshal/MarshalSizeOf2_PSC MarshalSizeOf2_PSC.exe
    _jdExitCode=$?
    if [ $_jdExitCode -ne 0 ]
    then
        echo EXECUTION OF JIT-DASM - FAILED $_jdExitCode
        exit 1
    fi
fi


# IlasmRoundTrip Script

# Disable Ilasm round-tripping for Linker tests.
# Todo: Ilasm round-trip on linked binaries.

if [ -z "$DoLink" -a ! -z "$RunningIlasmRoundTrip" ]
then
    echo "$CORE_ROOT/ildasm" -raweh -out=MarshalSizeOf2_PSC.dasm.il MarshalSizeOf2_PSC.dll
    "$CORE_ROOT/ildasm" -raweh -out=MarshalSizeOf2_PSC.dasm.il MarshalSizeOf2_PSC.dll
    ERRORLEVEL=$?
    if [ $ERRORLEVEL -ne 0 ]
    then
      echo EXECUTION OF ILDASM - FAILED $ERRORLEVEL
      exit 1
    fi

    echo "$CORE_ROOT/ilasm" -output=MarshalSizeOf2_PSC.asm.dll  MarshalSizeOf2_PSC.dasm.il
    "$CORE_ROOT/ilasm" -output=MarshalSizeOf2_PSC.asm.dll  MarshalSizeOf2_PSC.dasm.il
    ERRORLEVEL=$?
    if [ $ERRORLEVEL -ne 0 ]
    then
      echo EXECUTION OF ILASM - FAILED $ERRORLEVEL
      exit 1
    fi
fi
        
# Allow precommands to override the ExePath
ExePath=MarshalSizeOf2_PSC.dll
# PreCommands
# Long GC script
if [ ! -z $RunningLongGCTests ]
then
    echo "Skipping execution because this is not a long-running GC test"
    exit 0
fi
# GCSimulator script
if [ ! -z $RunningGCSimulatorTests ]
then
    echo "Skipping execution because this is not a GCSimulator test"
    exit 0
fi
# CrossGen Script
if [ ! -z ${RunCrossGen+x} ]; then
    export COMPlus_ZapRequire=2
    export COMPlus_ZapRequireList=MarshalSizeOf2_PSC
    if [ ! -f MarshalSizeOf2_PSC.org ]; then
        TakeLock
        if [ ! -f MarshalSizeOf2_PSC.org ]; then
          mkdir IL
          cp MarshalSizeOf2_PSC.dll IL/MarshalSizeOf2_PSC.dll
          mv MarshalSizeOf2_PSC.dll MarshalSizeOf2_PSC.org
          echo $_DebuggerFullPath "$CORE_ROOT/crossgen" /Platform_Assemblies_Paths $CORE_ROOT:$PWD/IL:$PWD /in MarshalSizeOf2_PSC.org /out MarshalSizeOf2_PSC.dll
          $_DebuggerFullPath "$CORE_ROOT/crossgen" /Platform_Assemblies_Paths $CORE_ROOT:$PWD/IL:$PWD /in MarshalSizeOf2_PSC.org /out MarshalSizeOf2_PSC.dll
          __cgExitCode=$?
          if [ $__cgExitCode -ne 0 ]
          then
            echo Crossgen failed with exitcode: $__cgExitCode
            ReleaseLock
            exit 1
          fi
        fi 
        ReleaseLock       
    fi        
fi        
        
# Launch


# Linker commands

LinkBin=__Link
Assemblies="-a System.Private.CoreLib"
ReflectionRoots=

shopt -s nullglob

if [ ! -z "$DoLink" ]
then
  if [ ! -x "$ILLINK" ]
then
    echo "Illink executable [$ILLINK] Invalid"
    exit 1
  fi
  
  # Clean up old Linked binaries, if any
  rm -rf $LinkBin
    
  # Remove Native images, since the goal is to run from Linked binaries
  rm -f *.ni.*

  # Use hints for reflection roots, if provided in MarshalSizeOf2_PSC.reflect.xml
  if [ -f MarshalSizeOf2_PSC.reflect.xml ]
then
    ReflectionRoots="-x MarshalSizeOf2_PSC.reflect.xml"
  fi

  # Include all .exe files in this directory as entry points (some tests had multiple .exe file modules)
  for bin in *.exe *.dll
do 
    Assemblies="$Assemblies -a ${bin%.*}"
  done

  # Run dotnet-linker
  # Run the Linker such that all assemblies except System.Private.Corlib.dll are linked
  # Debug symbol generation needs some fixes, and is currently omitted.
  # Once this is fixed, add -b true option.
  echo "$ILLINK -out $LinkBin -d $CORE_ROOT -c link -l none -t $Assemblies $ReflectionRoots"
  $ILLINK -out $LinkBin -d $CORE_ROOT -c link -l none -t $Assemblies $ReflectionRoots
  ERRORLEVEL=$?
  if [  $ERRORLEVEL -ne 0 ]
  then
    echo ILLINK FAILED $ERRORLEVEL
    if [ -z "$KeepLinkedBinaries" ]
then
      rm -rf $LinkBin
    fi
    exit 1
  fi
  
  # Copy CORECLR native binaries to $LinkBin, 
  # so that we can run the test based on that directory
  cp $CORE_ROOT/*.so $LinkBin/
  cp $CORE_ROOT/corerun $LinkBin/

  # Copy some files that may be arguments
  for f in *.txt
do
    [ -e "$f" ] && cp $f $LinkBin
  done

  ExePath=$LinkBin/MarshalSizeOf2_PSC.dll
  export CORE_ROOT=$PWD/$LinkBin
fi


if [ -z "$DoLink" -a ! -z "$RunningIlasmRoundTrip" ]
then
  echo  MarshalSizeOf2_PSC.asm.dll $(printf "'%s' " "${CLRTestExecutionArguments[@]}")
   MarshalSizeOf2_PSC.asm.dll "${CLRTestExecutionArguments[@]}"
  if [  $? -ne $CLRTestExpectedExitCode ]
  then
    echo END EXECUTION OF IL{D}ASM BINARY - FAILED $? vs $CLRTestExpectedExitCode
    echo FAILED
    exit 1
  fi
fi
        
if [ ! -z ${RunCrossGen+x} ]; then
  TakeLock
fi

if [ ! -z "$CLRCustomTestLauncher" ]
then
    LAUNCHER="$CLRCustomTestLauncher $PWD/"
else
    LAUNCHER="$_DebuggerFullPath "$CORE_ROOT/corerun""
fi

echo $LAUNCHER $ExePath $(printf "'%s' " "${CLRTestExecutionArguments[@]}")
$LAUNCHER $ExePath "${CLRTestExecutionArguments[@]}"

CLRTestExitCode=$?
if [ ! -z ${RunCrossGen+x} ]; then
  ReleaseLock
fi

# Clean up the LinkBin directories after test execution.
# Otherwise, RunTests may run out of disk space.

if [ ! -z "$DoLink" ]
then
  if [ -z "$KeepLinkedBinaries" ]
then
    rm -rf $LinkBin
  fi
fi

      
# PostCommands


echo Expected: $CLRTestExpectedExitCode
echo Actual: $CLRTestExitCode
if [ $CLRTestExitCode -ne $CLRTestExpectedExitCode ]
then
  echo END EXECUTION - FAILED
  exit 1
else
  echo END EXECUTION - PASSED
  exit 0
fi
